const navSlide = () => {
    const menu = document.querySelector('.menu');
    const nav = document.querySelector('.nav');

    menu.addEventListener('click', () => {
        nav.classList.toggle('showing');
    });

    nav.addEventListener('click', () => {
        nav.classList.toggle('showing');
    });
}

navSlide();